##############################################################################
############################# SPACE WALLS V 1.0 ##############################
################################### 2023 #####################################
# INSTALATION:                                                               #
# Extract the zip at your computer and create a desktop shortcut if you like #
# On Windows 10 / 11 UAC will prevent you from running the exe file.         #
# In the dialog box press more info and then run anyway.Also avoid extracting#
# the game in program files or any weird folder or there will be an error    #            # every time the game wants to access score.txt to save the highscore!       #
#----------------------------------------------------------------------------#
# space walls was a nice weekend challenge in python and pygame. Its not     #
# perfect but i had a great time making it! The walls are randomly generated #
# every time the game starts so no map is the same!                          #
#                                                                            #
# You can change the music by changing the .ogg files found it the           #
# sounds/music folder with whatever you like.                                #
#                                                                            #
# Also the score can be changed (or set to 0) by changing the txt file in    #
# the include folder (just add numbers only) but beware: theres a finite     #
# number of walls in the game.. Dont be a cheater!                           #
#----------------------------------------------------------------------------#
# You can find more of my projects at https://github.com/cloudconstructor    #
#                                                                            # 
##############################################################################

